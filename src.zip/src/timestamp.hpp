#pragma once

#include <string>

std::string time_in_HH_MM_SS_MMM();
