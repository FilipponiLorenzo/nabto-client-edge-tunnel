#include "version.hpp"

static const char* version_str = "1.0.0-develop.128+3f890ef.dirty"
;
const char* edge_tunnel_client_version() { return version_str; }
