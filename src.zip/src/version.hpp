#ifndef NC_VERSION_H
#define NC_VERSION_H

#define NABTO_PROTOCOL_VERSION "n5"

extern const char* edge_tunnel_client_version();

#endif // NC_VERSION_H
